#!/bin/bash
#

sleep 2
env | grep '^PROXY_' | sort 1>&2
cat 1>&2

exit 0

